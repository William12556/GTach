#!/bin/bash
# GTach Application Installation Script
# Generated: 2025-08-15T13:56:07.205659
# Target Platform: Raspberry Pi

set -e

echo "Installing gtach v0.1.0-dev..."

# Check if running on Raspberry Pi
if ! grep -q "Raspberry Pi" /proc/device-tree/model 2>/dev/null; then
    echo "Warning: This package is designed for Raspberry Pi"
fi

# Create application directory
APP_DIR="/opt/gtach"
sudo mkdir -p "$APP_DIR"

# Copy application files
echo "Installing application files..."
sudo cp -r src/* "$APP_DIR/"

# Install Python dependencies
if [ -f "requirements.txt" ]; then
    echo "Installing Python dependencies..."
    pip3 install -r requirements.txt
fi

# Set permissions
sudo chown -R pi:pi "$APP_DIR"
sudo chmod +x "$APP_DIR"/*.py

# Create systemd service if service file exists
if [ -f "gtach.service" ]; then
    echo "Installing systemd service..."
    sudo cp gtach.service /etc/systemd/system/
    sudo systemctl daemon-reload
    sudo systemctl enable gtach
fi

echo "Installation completed successfully!"
echo "Application installed to: $APP_DIR"
